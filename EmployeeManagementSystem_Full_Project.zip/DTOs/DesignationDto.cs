
namespace EmployeeManagementSystem.DTOs
{
    public class DesignationDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
