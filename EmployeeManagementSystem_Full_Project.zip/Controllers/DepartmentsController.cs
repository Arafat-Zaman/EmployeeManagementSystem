
using Microsoft.AspNetCore.Mvc;
using MediatR;
using EmployeeManagementSystem.Features.Departments.Commands;
using EmployeeManagementSystem.Features.Departments.Queries;

namespace EmployeeManagementSystem.Controllers
{
    [ApiController]
    [Route("api/v1/departments")]
    public class DepartmentsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public DepartmentsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllDepartments()
        {
            var query = new GetAllDepartmentsQuery();
            var result = await _mediator.Send(query);
            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateDepartment([FromBody] CreateDepartmentCommand command)
        {
            var result = await _mediator.Send(command);
            return CreatedAtAction(nameof(GetAllDepartments), new { id = result }, result);
        }
    }
}
