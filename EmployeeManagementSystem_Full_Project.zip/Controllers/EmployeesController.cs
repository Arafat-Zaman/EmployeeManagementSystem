
using Microsoft.AspNetCore.Mvc;
using MediatR;
using EmployeeManagementSystem.Features.Employees.Commands;
using EmployeeManagementSystem.Features.Employees.Queries;

namespace EmployeeManagementSystem.Controllers
{
    [ApiController]
    [Route("api/v1/employees")]
    public class EmployeesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public EmployeesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEmployees()
        {
            var query = new GetAllEmployeesQuery();
            var result = await _mediator.Send(query);
            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEmployee([FromBody] CreateEmployeeCommand command)
        {
            var result = await _mediator.Send(command);
            return CreatedAtAction(nameof(GetAllEmployees), new { id = result }, result);
        }
    }
}
