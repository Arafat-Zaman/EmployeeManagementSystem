
using MediatR;
using System.Collections.Generic;

namespace EmployeeManagementSystem.Features.Employees.Queries
{
    public record GetAllEmployeesQuery : IRequest<List<EmployeeDto>>;
}
