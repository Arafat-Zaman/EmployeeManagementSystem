
using MediatR;

namespace EmployeeManagementSystem.Features.Employees.Commands
{
    public record CreateEmployeeCommand(string FirstName, string LastName, int DepartmentId, int DesignationId) : IRequest<int>;
}
