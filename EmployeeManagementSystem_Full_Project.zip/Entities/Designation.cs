
namespace EmployeeManagementSystem.Entities
{
    public class Designation
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
