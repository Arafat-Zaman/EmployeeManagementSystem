
# Employee Management System

## Description
This project is an ASP.NET Core Web API for managing employees, departments, and designations using a modern architecture.

## Features
- CRUD operations for employees, departments, and designations
- JWT-based authentication and authorization
- Centralized exception handling
- API versioning
- Containerized deployment with Docker

## Prerequisites
- [.NET SDK](https://dotnet.microsoft.com/download)
- [SQL Server](https://www.microsoft.com/en-us/sql-server/sql-server-downloads)
- [Docker](https://www.docker.com/)

## Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/YourRepo/EmployeeManagementSystem.git
   ```
2. Configure `appsettings.json`:
   - Set the `DefaultConnection` string for your SQL Server.
   - Update the `JwtConfig` settings.

3. Run the application:
   ```bash
   dotnet run
   ```

4. Test the API using Swagger:
   - Navigate to `http://localhost:5000/swagger`.

## Docker Deployment
1. Build the Docker image:
   ```bash
   docker build -t employee-management-system .
   ```
2. Run the Docker container:
   ```bash
   docker run -p 8080:80 employee-management-system
   ```

## Author
- **Your Name** - Developer
